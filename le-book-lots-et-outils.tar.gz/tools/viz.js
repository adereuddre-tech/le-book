const fs=require('fs'),{JSDOM}=require('jsdom');
const dom=new JSDOM(fs.readFileSync('index.html','utf8'),{runScripts:'dangerously',url:'https://x/'});
const w=dom.window;
setTimeout(()=>{try{console.log(w.eval(`(()=>{
 const o=[];
 screenIntro();
 o.push('accueil : bandeau='+document.querySelectorAll('.tick').length+' courbes='+document.querySelectorAll('svg.navc').length
  +' tuiles marches='+document.querySelectorAll('.mw').length+' concurrents='+document.querySelectorAll('.riv').length
  +' portraits='+document.querySelectorAll('.riv svg.ava').length);
 const r=document.querySelector('.navrow');o.push('  legende : '+r.textContent.replace(/\\s+/g,' ').trim());
 o.push('  boutons : '+[...document.querySelectorAll('button.cta')].map(b=>b.id).join(', '));
 /* courbe de cloture et rapport final sur une vraie partie */
 newGame(4,'fonda','std','inhouse','std','mid','com','normal');S.fundName='Test Capital';
 S.rets=[0.04,-0.11,0.06,0.02];S.navs=[0.1,0.104,0.0925,0.098,0.1];S.regimes=['range','crise','range','reprise'];
 S.idx=1.004;
 const sv=idxSeries();o.push('serie indice : '+sv.map(x=>x.toFixed(1)).join(' → '));
 const box=navBox('TEST',sv,{anim:1,trough:1});
 o.push('encadre : svg='+/svg class="navc"/.test(box)+' creux marque='+/circle cx=[^>]*fill="#C4576F"/.test(box));
 o.push('  legende : '+box.replace(/<[^>]*>/g,' ').replace(/\\s+/g,' ').trim());
 return o.join('\\n')})()`))}catch(e){console.log('ERR',e.message,e.stack&&e.stack.split('\\n')[1])}dom.window.close()},1500);
