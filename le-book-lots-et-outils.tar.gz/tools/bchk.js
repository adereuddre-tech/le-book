const fs=require('fs'),{JSDOM}=require('jsdom');
const dom=new JSDOM(fs.readFileSync(process.argv[2]||'index.html','utf8'),{runScripts:'dangerously',url:'https://x/'});
setTimeout(()=>{console.log(dom.window.eval(`(()=>{
 const lab=b=>{const a=Math.abs(b);const n=a<0.15?0:a>=0.55?3:a>=0.32?2:1;return n===0?'0':(b>0?'+':'−')+n};
 const out=[];
 newGame(1,'fonda','std','inhouse','std','mega','ext','normal');
 INSTR.forEach(x=>{const q=x.b.reduce((a,v)=>a+v*v,0);
  out.push(x.sym.padEnd(5)+x.b.map(lab).join(' ')+'  Σb²='+q.toFixed(3)+' idio='+x.idio.toFixed(2))});
 /* valeur propre minimale de la covariance, par puissance inverse grossière */
 const n=N;let lo=1e9;
 const A=COV.map(r=>r.slice());
 /* Gershgorin : borne inférieure suffisante ici */
 for(let i=0;i<n;i++){let r=0;for(let j=0;j<n;j++)if(i!==j)r+=Math.abs(A[i][j]);lo=Math.min(lo,A[i][i]-r)}
 out.push('borne de Gershgorin sur λmin : '+lo.toFixed(4));
 return out.join('\\n')})()`));dom.window.close()},1500);
