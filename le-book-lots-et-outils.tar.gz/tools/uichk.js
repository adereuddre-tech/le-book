const fs=require('fs'),{JSDOM}=require('jsdom');
const dom=new JSDOM(fs.readFileSync('index.html','utf8'),{runScripts:'dangerously',url:'https://x/'});
const w=dom.window;
setTimeout(()=>{try{console.log(w.eval(`(()=>{
 const out=[];
 newGame(4,'fonda','std','inhouse','std','mid','com','normal');S.fundName='Test Capital';
 S.budBp=34;genRumors();const R=recoBook();S.k=R.k.slice();S.k0=new Array(N).fill(0);
 out.push('— source vérifiée : '+(S.rumors.filter(r=>r.sure).map(r=>r.src+' | pastille='+(r.sure?'oui':'non')).join('')||'aucune ce trimestre'));
 out.push('— pré-annonces : '+S.rumors.filter(r=>r.ev).map(r=>r.t.slice(0,60)).join(' // ')||'aucune');
 commitOrders();screenComm();
 out.push('— écran annonce : bouton doré #commok présent ? '+(!!document.getElementById('commok'))+' ; cartes cliquables : '+document.querySelectorAll('.card.commgo').length);
 document.querySelectorAll('.card.commgo')[1].click();
 out.push('— après clic : on est sur '+(document.querySelector('.blockhead h2')?document.querySelector('.blockhead h2').textContent:'?'));
 out.push('— détail des ordres replié ? '+(document.querySelector('details')&&!document.querySelector('details').open));
 const kv=[...document.querySelectorAll('.kv')].map(x=>x.textContent.replace(/\\s+/g,' ').trim()).slice(0,2);
 out.push('— toujours visible : '+kv.join(' || '));
 return out.join('\\n')})()`))}catch(e){console.log('ERR',e.message)}dom.window.close()},1500);
