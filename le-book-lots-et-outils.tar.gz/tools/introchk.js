const fs=require('fs'),{JSDOM}=require('jsdom');
const html=fs.readFileSync(process.argv[2]||'index.html','utf8');
const errs=[];
const dom=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x/',virtualConsole:new (require('jsdom').VirtualConsole)().on('jsdomError',e=>errs.push(String(e)))});
const w=dom.window;
w.onerror=(m)=>errs.push(String(m));
setTimeout(()=>{
 const d=w.document;
 const h=d.getElementById('app').innerHTML;
 const chk={
  tick:/class="tick"/.test(h), nav:/class="navc"/.test(h), wall:(h.match(/class="mw /g)||[]).length,
  rivs:(h.match(/class="riv"/g)||[]).length, found:!!d.getElementById('found'),
  undef:/undefined|NaN/.test(h), hall:!!d.getElementById('hall')};
 console.log(JSON.stringify({errs,chk}));
 dom.window.close();
},1200);
