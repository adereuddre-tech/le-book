const fs=require('fs'),{JSDOM}=require('jsdom');
const dom=new JSDOM(fs.readFileSync(process.argv[2]||'index.html','utf8'),{runScripts:'dangerously',url:'https://x/'});
setTimeout(()=>{
 const w=dom.window;
 const out=w.eval(`(()=>{const R={};
  [['mega','ext'],['mid','com'],['small','fin']].forEach(([sz,un])=>{
   setUniverse(sz,un);resetB();
   const C=[];for(let i=0;i<N;i++){C[i]=[];for(let j=0;j<N;j++)C[i][j]=COV[i][j]/(INSTR[i].sig*INSTR[j].sig)}
   R[sz+'/'+un]={n:N,C};});
  return JSON.stringify(R)})()`);
 const R=JSON.parse(out);
 // puissance inverse simple : valeurs propres par Jacobi
 function eig(A){const n=A.length;let M=A.map(r=>r.slice());
  for(let s=0;s<200;s++){let p=0,q=1,mx=0;
   for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)if(Math.abs(M[i][j])>mx){mx=Math.abs(M[i][j]);p=i;q=j}
   if(mx<1e-10)break;
   const th=0.5*Math.atan2(2*M[p][q],M[p][p]-M[q][q]),c=Math.cos(th),si=Math.sin(th);
   const N2=M.map(r=>r.slice());
   for(let k=0;k<n;k++){N2[p][k]=c*M[p][k]+si*M[q][k];N2[q][k]=-si*M[p][k]+c*M[q][k]}
   const N3=N2.map(r=>r.slice());
   for(let k=0;k<n;k++){N3[k][p]=c*N2[k][p]+si*N2[k][q];N3[k][q]=-si*N2[k][p]+c*N2[k][q]}
   M=N3}
  return M.map((r,i)=>r[i]).sort((a,b)=>a-b)}
 for(const k in R){const e=eig(R[k].C);
  console.log(k,'n='+R[k].n,'lmin='+e[0].toFixed(3),'lmax='+e[e.length-1].toFixed(3),'cond='+(e[e.length-1]/e[0]).toFixed(1))}
 let s=0,n=0,mn=9;R['mega/ext'].C.forEach((r,i)=>r.forEach((v,j)=>{if(i<j){s+=v;n++;mn=Math.min(mn,v)}}));
 console.log('corr moyenne',(s/n).toFixed(3),'min',mn.toFixed(3));
 dom.window.close()},1500);
