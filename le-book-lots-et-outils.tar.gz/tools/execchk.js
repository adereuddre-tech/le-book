const fs=require('fs'),{JSDOM}=require('jsdom');
const dom=new JSDOM(fs.readFileSync('index.html','utf8'),{runScripts:'dangerously',url:'https://x/'});
const w=dom.window;
setTimeout(()=>{
 try{
 const out=w.eval(`(()=>{
  const res=[];
  for(let seed=1;seed<60&&res.length<3;seed++){
   newGame(seed,'fonda','std','inhouse','std','mid','com','normal');S.fundName='Test Capital';
   S.budBp=34;genRumors();const R=recoBook();S.k=R.k.slice();S.k0=new Array(N).fill(0);
   commitOrders();S.comm={id:'prud',nm:'x',ret:0.03,win:{lp:0,rc:0},lose:{lp:0,rc:0}};
   screenExec();
   const ch=[...document.querySelectorAll('button.choice')].map(b=>b.textContent.replace(/\\s+/g,' ').trim());
   res.push('graine '+seed+' — '+ch.length+' options\\n  '+ch.join('\\n  '));
  }
  return res.join('\\n\\n');})()`);
 console.log(out);}catch(e){console.log('ERR',e.message)}
 dom.window.close();
},1500);
