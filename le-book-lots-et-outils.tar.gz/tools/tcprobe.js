const fs=require('fs'),{JSDOM}=require('jsdom');
const dom=new JSDOM(fs.readFileSync(process.argv[2]||'index.html','utf8'),{runScripts:'dangerously',url:'https://x/'});
setTimeout(()=>{console.log(dom.window.eval(`(()=>{
 newGame(5,'fonda','std','inhouse','std','mid','com','normal');genRumors();
 const R=recoBook();S.k=R.k.slice();if(!S.k.some(v=>v))S.k=INSTR.map((x,i)=>i%2?2:-2);
 let tot=0;for(let i=0;i<N;i++){if(S.k[i])tot+=tcost(S.k[i],i).cost}
 const g=grossBn(S.k);
 return JSON.stringify({navM:S.nav*1000,brutM:g*1000,ordreM:tot*1000,bpNav:tot/S.nav*1e4,bpNot:tot/g*1e4})})()`));dom.window.close()},1500);
