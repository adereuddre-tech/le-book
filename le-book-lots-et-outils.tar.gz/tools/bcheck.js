const fs=require('fs'),{JSDOM}=require('jsdom');
const dom=new JSDOM(fs.readFileSync(process.argv[2]||'index.html','utf8'),{runScripts:'dangerously',url:'https://x/'});
setTimeout(()=>{console.log(dom.window.eval(`(()=>{
 const lab=b=>{const a=Math.abs(b);if(a<0.15)return '0';const n=a>=0.55?3:a>=0.32?2:1;return (b>0?'+':'-')+n};
 const out=INSTR_ALL.map(x=>{const q=x.b.reduce((a,v)=>a+v*v,0);
  return [x.sym,x.grp.slice(0,4),x.b.map(lab).join(' '),q.toFixed(3),(q>0.92?'RENORMALISE':'')].join('\\t')});
 return out.join('\\n')})()`));dom.window.close()},1200);
